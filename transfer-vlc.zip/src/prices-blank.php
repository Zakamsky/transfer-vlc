<?php ?>

<div class="tab_nav">
    <div class="nav nav-tabs" id="nav-tab" role="tablist">
        <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="ali_price" aria-selected="true">Home</a>
        <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Profile</a>
    </div>
</div>
<div class="tab-content" id="nav-tabContent">
    <div class="tab-pane fade show active" id="ali_price" role="tabpanel" aria-labelledby="nav-home-tab">...</div>
    <div class="tab-pane fade" id="vlc-price" role="tabpanel" aria-labelledby="nav-profile-tab">тут будет вторая таблица</div>
</div>
